//
// urlencode.c - urlencode string, public domain
//
// Part of grblHAL
//

#pragma once

int urlencode (const char *uri, const char *encoded, size_t size);
