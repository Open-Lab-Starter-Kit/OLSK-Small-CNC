## Encoder plugin

This plugin can be used for quadrature encoder input to adjust overrides. Jogging is planned.

Dependencies:

Driver must have low level support for at least one encoder. Up to five is supported.

---
2020-09-13
